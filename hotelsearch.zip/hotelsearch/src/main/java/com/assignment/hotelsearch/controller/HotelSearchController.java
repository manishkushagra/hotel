package com.assignment.hotelsearch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.hotelsearch.dto.HotelReview;
import com.assignment.hotelsearch.dto.NamesOfHotels;
import com.assignment.hotelsearch.service.HotelSearchService;

@RestController
public class HotelSearchController {

	@Autowired
	HotelSearchService hss;
	
	@RequestMapping(value="/{str}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<String> cityNames( @PathVariable String str){
		System.out.println("inside controller" + str);
		return hss.cityNames(str);
	}
	
	@RequestMapping(value="/hotel/{id}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<HotelReview> hotelReview( @PathVariable int id){
		System.out.println("inside controller" + id);
		return hss.hotelReview(id);
	}
	
	@RequestMapping(value="/{city}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<NamesOfHotels> hotelList( @PathVariable String city){
		System.out.println("inside controller" + city);
		return hss.hotelList(city);
	}
}
