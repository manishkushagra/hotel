package com.assignment.hotelsearch.dto;

import com.assignment.hotelsearch.entity.HotelList;

public class HotelSearchDTO {
	private int id;
	private String address;
	private String categories;
	private String city;
	private String country;
	private double latitude;
	private double longitude;
	private String name;
	private String postalcod ;
	private String province ;
	private int reviews_rating;
	private String reviews_title ;
	private String reviews_text ;
	private String reviews_username;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPostalcod() {
		return postalcod;
	}
	public void setPostalcod(String postalcod) {
		this.postalcod = postalcod;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public int getReviews_rating() {
		return reviews_rating;
	}
	public void setReviews_rating(int reviews_rating) {
		this.reviews_rating = reviews_rating;
	}
	public String getReviews_title() {
		return reviews_title;
	}
	public void setReviews_title(String reviews_title) {
		this.reviews_title = reviews_title;
	}
	public String getReviews_text() {
		return reviews_text;
	}
	public void setReviews_text(String reviews_text) {
		this.reviews_text = reviews_text;
	}
	public String getReviews_username() {
		return reviews_username;
	}
	public void setReviews_username(String reviews_username) {
		this.reviews_username = reviews_username;
	}
	public HotelSearchDTO(int id, String address, String categories, String city, String country, double latitude,
			double longitude, String name, String postalcod, String province, int reviews_rating,
			String reviews_title, String reviews_text, String reviews_username) {
		super();
		this.id = id;
		this.address = address;
		this.categories = categories;
		this.city = city;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		this.name = name;
		this.postalcod = postalcod;
		this.province = province;
		this.reviews_rating = reviews_rating;
		this.reviews_title = reviews_title;
		this.reviews_text = reviews_text;
		this.reviews_username = reviews_username;
	}
	public HotelSearchDTO() {
		super();
	}
	
	@Override
	public String toString() {
		return "HotelSearchDTO [id=" + id + ", address=" + address + ", categories=" + categories + ", city=" + city
				+ ", country=" + country + ", latitude=" + latitude + ", longitude=" + longitude + ", name=" + name
				+ ", postalcod=" + postalcod + ", province=" + province + ", reviews_rating=" + reviews_rating
				+ ", reviews_title=" + reviews_title + ", reviews_text=" + reviews_text + ", reviews_username="
				+ reviews_username + "]";
	}
	
	public static HotelSearchDTO toHsDTO(HotelList hs) {
		HotelSearchDTO hd = new HotelSearchDTO();
		hd.id = hs.getId();
		hd.address = hs.getAddress();
		hd.categories = hs.getCategories();
		hd.city = hs.getCity();
		hd.country = hs.getCountry();
		hd.latitude = hs.getLatitude();
		hd.longitude = hs.getLongitude();
		hd.name = hs.getName();
		hd.postalcod = hs.getPostalcod();
		hd.province = hs.getProvince();
		hd.reviews_rating = hs.getReviews_rating();
		hd.reviews_title = hs.getReviews_title();
		hd.reviews_text = hs.getReviews_text();
		hd.reviews_username = hs.getReviews_username();
		return hd;
	}
}
