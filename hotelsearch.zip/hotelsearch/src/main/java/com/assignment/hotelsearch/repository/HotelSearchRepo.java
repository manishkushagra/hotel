package com.assignment.hotelsearch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.assignment.hotelsearch.entity.HotelList;

@Repository
public interface HotelSearchRepo extends JpaRepository<HotelList, Integer> {

	List<HotelList> findAllByCity(String city);

	HotelList findAllById(int id);
	
}
