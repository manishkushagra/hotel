package com.assignment.hotelsearch.dto;

public class HotelReview {
	private int id;
	private String name;
	private int reviews_rating;
	private String reviews_text;
	private String reviews_title;
	private String reviews_username;
	private String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getReviews_rating() {
		return reviews_rating;
	}
	public void setReviews_rating(int reviews_rating) {
		this.reviews_rating = reviews_rating;
	}
	public String getReviews_text() {
		return reviews_text;
	}
	public void setReviews_text(String reviews_text) {
		this.reviews_text = reviews_text;
	}
	public String getReviews_title() {
		return reviews_title;
	}
	public void setReviews_title(String reviews_title) {
		this.reviews_title = reviews_title;
	}
	public String getReviews_username() {
		return reviews_username;
	}
	public void setReviews_username(String reviews_username) {
		this.reviews_username = reviews_username;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public HotelReview(int id, String name, int reviews_rating, String reviews_text, String reviews_title,
			String reviews_username, String address) {
		super();
		this.id = id;
		this.name = name;
		this.reviews_rating = reviews_rating;
		this.reviews_text = reviews_text;
		this.reviews_title = reviews_title;
		this.reviews_username = reviews_username;
		this.address = address;
	}
	public HotelReview() {
		super();
	}
	@Override
	public String toString() {
		return "HotelReview [id=" + id + ", name=" + name + ", reviews_rating=" + reviews_rating + ", reviews_text="
				+ reviews_text + ", reviews_title=" + reviews_title + ", reviews_username=" + reviews_username
				+ ", address=" + address + "]";
	}
	public static HotelReview toHotelReview(HotelSearchDTO hd) {
		HotelReview hr= new HotelReview();
		hr.id = hd.getId();
		hr.name = hd.getName();
		hr.reviews_rating = hd.getReviews_rating();
		hr.reviews_text = hd.getReviews_text();
		hr.reviews_title = hd.getReviews_title();
		hr.reviews_username = hd.getReviews_username();
		hr.address = hd.getAddress();
		return hr;
	}
}
