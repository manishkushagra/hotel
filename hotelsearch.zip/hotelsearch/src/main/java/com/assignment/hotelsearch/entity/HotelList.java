package com.assignment.hotelsearch.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hotellist")
public class HotelList {
	@Id
	private int id;
	private String address;
	private String categories;
	private String city;
	private String country;
	private double latitude;
	private double longitude;
	private String name;
	@Column(name="postalCode")
	private String postalcod ;
	private String province ;
	
	@Column(name="review.rating")
	private int reviews_rating;
	
	@Column(name="review.title")
	private String reviews_title;
	
	@Column(name="review.text")
	private String reviews_text;
	
	@Column(name="review.username")
	private String reviews_username;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPostalcod() {
		return postalcod;
	}
	public void setPostalcod(String postalcod) {
		this.postalcod = postalcod;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public int getReviews_rating() {
		return reviews_rating;
	}
	public void setReviews_rating(int reviews_rating) {
		this.reviews_rating = reviews_rating;
	}
	public String getReviews_title() {
		return reviews_title;
	}
	public void setReviews_title(String reviews_title) {
		this.reviews_title = reviews_title;
	}
	public String getReviews_text() {
		return reviews_text;
	}
	public void setReviews_text(String reviews_text) {
		this.reviews_text = reviews_text;
	}
	public String getReviews_username() {
		return reviews_username;
	}
	public void setReviews_username(String reviews_username) {
		this.reviews_username = reviews_username;
	}
	public HotelList(int id, String address, String categories, String city, String country, double latitude,
			double longitude, String name, String postalcod, String province, int reviews_rating,
			String reviews_title, String reviews_text, String reviews_username) {
		super();
		this.id = id;
		this.address = address;
		this.categories = categories;
		this.city = city;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		this.name = name;
		this.postalcod = postalcod;
		this.province = province;
		this.reviews_rating = reviews_rating;
		this.reviews_title = reviews_title;
		this.reviews_text = reviews_text;
		this.reviews_username = reviews_username;
	}
	public HotelList() {
		super();
	}
	
}
