package com.assignment.hotelsearch.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.hotelsearch.dto.HotelReview;
import com.assignment.hotelsearch.dto.HotelSearchDTO;
import com.assignment.hotelsearch.dto.NamesOfHotels;
import com.assignment.hotelsearch.entity.HotelList;
import com.assignment.hotelsearch.repository.HotelSearchRepo;

@Service
public class HotelSearchService {
	
	@Autowired
	HotelSearchRepo hsRepo;
	
	public List<String> cityNames(String start){
	
		List<String> cities=new ArrayList<>();
		
		try {
			List<HotelList> hse=hsRepo.findAll();
			List<HotelSearchDTO> hsd=new ArrayList<>();
			Set<String> set =new HashSet<>();
			if(!hse.isEmpty()) {
				hse.forEach(entity->{
					hsd.add(HotelSearchDTO.toHsDTO(entity));
				});
				hsd.forEach(dto->{
					if(dto.getCity().toLowerCase().startsWith(start.toLowerCase()))
						set.add(dto.getCity());
						
				});
				cities=set.stream().sorted().collect(Collectors.toList());
			}
		}
		catch(Exception e) {
			System.out.println("inside catch " + e.getMessage());
		}
		return cities;
	}
	
	public HotelReview hotelReview(int id){
		HotelReview list=null; 
		HotelList hse=hsRepo.findAllById(id);
		HotelSearchDTO hsd;
		try {
			hsd=HotelSearchDTO.toHsDTO(hse);
			list=HotelReview.toHotelReview(hsd);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return list;
	}
	public List<NamesOfHotels> hotelList(String city){
		
		List<NamesOfHotels> list=new ArrayList<>(); 
		List<HotelList> hse=hsRepo.findAllByCity(city);
		List<HotelSearchDTO> hsd=new ArrayList<>();
		try {
			if(!hse.isEmpty()) {
				hse.forEach(entity->{
					hsd.add(HotelSearchDTO.toHsDTO(entity));
				});
				hsd.forEach(dto->{
					list.add(NamesOfHotels.toNamesOfHotels(dto));
						
				});
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return list;
	}
	
}
