package com.assignment.hotelsearch.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.hotelsearch.dto.HotelReview;
import com.assignment.hotelsearch.dto.HotelSearchDTO;
import com.assignment.hotelsearch.dto.NamesOfHotels;
import com.assignment.hotelsearch.entity.HotelList;
import com.assignment.hotelsearch.repository.HotelSearchRepo;

@Service
public class HotelSearchService {
	
	@Autowired
	HotelSearchRepo hsRepo;
	
	public List<String> cityNames(String start){
		
		System.out.println("inside service "+ start);
		List<String> cities=new ArrayList<>();
		
		try {
		List<HotelList> hse=hsRepo.findAll();
		System.out.println("inside service 1 "+ start);

		List<HotelSearchDTO> hsd=new ArrayList<>();
		Set<String> set =new HashSet<>();
		
		
		System.out.println("inside service 2 "+ start);
		
		if(!hse.isEmpty()) {
			hse.forEach(entity->{
				hsd.add(HotelSearchDTO.toHsDTO(entity));
			});
			hsd.forEach(dto->{
				if(dto.getCity().toLowerCase().startsWith(start.toLowerCase()))
					set.add(dto.getCity());
					
			});
			cities=set.stream().sorted().collect(Collectors.toList());
		}
		}
		catch(Exception e) {
			System.out.println("inside catch " + e.getMessage());
		}
		return cities;
	}
	
	public List<HotelReview> hotelReview(int id){
		return null;
	}
	public List<NamesOfHotels> hotelList(String city){
		return null;
	}
}
