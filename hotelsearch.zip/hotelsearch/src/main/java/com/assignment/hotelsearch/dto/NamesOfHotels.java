package com.assignment.hotelsearch.dto;

public class NamesOfHotels {
	private int id;
	private String name;
	private String address;
	private int reviews_rating;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getReviews_rating() {
		return reviews_rating;
	}
	public void setReviews_rating(int reviews_rating) {
		this.reviews_rating = reviews_rating;
	}
	public NamesOfHotels(int id, String name, String address, int reviews_rating) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.reviews_rating = reviews_rating;
	}
	public NamesOfHotels() {
		super();
	}
	
	@Override
	public String toString() {
		return "NamesOfHotels [id=" + id + ", name=" + name + ", address=" + address + ", reviews_rating="
				+ reviews_rating + "]";
	}
	
	public static NamesOfHotels toNamesOfHotels(HotelSearchDTO hd) {
		NamesOfHotels noh = new NamesOfHotels();
		noh.id = hd.getId();
		noh.name = hd.getName();
		noh.address = hd.getAddress();
		noh.reviews_rating = hd.getReviews_rating();;
		return noh;
	}
}
